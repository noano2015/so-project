/**
 * @file api.c
 * 
 * @author Pedro Vicente (ist1109852), Pedro Jerónimo (ist1110375)
 * 
 * @brief An api in order to process the information that will be sent
 * to the server by the client to execute its requets and receive the
 * server's response.
 * 
 * @copyright Copyright (c) 2025
 * 
 */

#include "api.h"
#include "../common/constants.h"
#include "../common/protocol.h"
#include "../common/io.h"
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>
#include <bits/types/sigset_t.h>
#include <signal.h>
#include <bits/sigaction.h>
#include <pthread.h>

#define NOT_EXISTENT -1

// the file descriptores of the client's pipes
int req_fd = NOT_EXISTENT, resp_fd = NOT_EXISTENT, notif_fd = NOT_EXISTENT;

//the client's pipes paths
char req_path[MAX_PIPE_PATH_LENGTH] = {'\0'},
      resp_path[MAX_PIPE_PATH_LENGTH] = {'\0'},
      notif_path[MAX_PIPE_PATH_LENGTH] = {'\0'};
int count_keys = 0;

int close_and_unlink(){
  // Closes pipes and unlinks pipes files
  if(req_fd != NOT_EXISTENT)close(req_fd);
  if(resp_fd != NOT_EXISTENT)close(resp_fd);
  if(notif_fd != NOT_EXISTENT )close(notif_fd);

  if(unlink(req_path) != 0 && errno != ENOENT){
    fprintf(stderr, "Unlink(%s) failed.\n", req_path);
    return 1;
  }
  if(unlink(resp_path) != 0 && errno != ENOENT){
    fprintf(stderr, "Unlink(%s) failed.\n", resp_path);
    return 1;
  }
  if(unlink(notif_path) != 0 && errno != ENOENT){
    fprintf(stderr, "Unlink(%s) failed.\n", notif_path);
    return 1;
  }
  return 0;
}

int kvs_connect(char const* req_pipe_path, char const* resp_pipe_path,
                char const* server_pipe_path, char const* notif_pipe_path,
                int* notif_pipe){
  // Block EPIPE
  sigset_t sigset;
  sigemptyset(&sigset);
  sigaddset(&sigset, EPIPE);
  if(pthread_sigmask(SIG_BLOCK, &sigset, NULL) != 0){
    fprintf(stderr,"[API] Failed to mask EPIPE.\n");
    pthread_exit(NULL);
  }
  
  // Copies every pipe path in order to be accessible for other functions of the api
  strcpy(req_path, req_pipe_path);
  strcpy(resp_path, resp_pipe_path);
  strcpy(notif_path, notif_pipe_path);

  if(close_and_unlink()){
    fprintf(stderr, "[API] Falied to unlink and close the client's fifos.\n");
    return 1;
  }

  // Creates the request pipe
  if(mkfifo(req_pipe_path, 0640) != 0){
    fprintf(stderr, "[API] Failed to create request pipe.\n");
    return 1;
  }

  // Creates the response pipe
  if(mkfifo(resp_pipe_path, 0640) != 0){
    fprintf(stderr, "[API] Failed to create response pipe.\n");
    close_and_unlink();
    return 1;
  }

  // Creates the notifications pipe
  if(mkfifo(notif_pipe_path, 0640) != 0){
    close_and_unlink();
    fprintf(stderr, "[API] Failed to create notifications pipe.\n");
    return 1;
  }

  // Opens server pipe
  int server_fd;
  if((server_fd = open(server_pipe_path, O_WRONLY)) < 0){
    fprintf(stderr, "[API] Failed to open the server pipe.\n");
    close_and_unlink();
    return 1;
  }

  // Creates the connection request to be sent to the server
  // content of the message:
  // OP_CODE = 1
  // request pipe path
  // response pipe path
  // notifications pipe path
  char message[3*MAX_PIPE_PATH_LENGTH + 1] = {'\0'};
  if(sprintf(message, "%d", OP_CODE_CONNECT) < 0 
     || snprintf(message + 1, MAX_PIPE_PATH_LENGTH, "%s", req_path) < 0
     || snprintf(message + 1 + MAX_PIPE_PATH_LENGTH, MAX_PIPE_PATH_LENGTH, "%s", resp_path) < 0
     || snprintf(message + 1 + 2*MAX_PIPE_PATH_LENGTH, MAX_PIPE_PATH_LENGTH, "%s", notif_path) < 0){
      close_and_unlink();
      fprintf(stderr, "[API] Failed to create connection request.\n");
      return 1;
     }

  // Writes the connection request to the server pipe
  if(write_all(server_fd, message, 3*MAX_PIPE_PATH_LENGTH + 1) == -1){
    fprintf(stderr, "[API] Failed to write the connection request to the server pipe.\n");
    close_and_unlink();
    return 1;
  }

  close(server_fd);

  // Opens the client pipes
  resp_fd = open(resp_pipe_path, O_RDONLY);
  req_fd = open(req_pipe_path, O_WRONLY);
  notif_fd = open(notif_pipe_path, O_RDONLY);
  *notif_pipe = notif_fd;

  // Reads the result of the connection from the response pipe
  char result[2] = {'\0'};
  if(read_all(resp_fd, result, 2, NULL) <= 0){
    fprintf(stderr, "[API] Failed to read the connection result from the response pipe.\n");
    close_and_unlink();
    return 1;
  }

  // Prints the result of the operation
  char response[45] = {'\0'};
  if(snprintf(response, 45,
     "Server returned %c for operation: connect.\n", result[1]) < 0){
    fprintf(stderr,"[API] Error in creating the message obtained form the server.\n");
    return 1;
  }
  write_all(1, response, 45);

  if(result[1] - '0' == 1)
    close_and_unlink();
  
  return result[1] - '0';
}
 
int kvs_disconnect(int force_closing){
  char message[2] = {'\0'};

  // In case that the connection to the server is lost unpredicably
  // closes and unlinks the client pipes. Otherwise, sends a 
  // disconnection request to the server
  if(!force_closing){
    // Creates the disconnection request to be sent to the server
    if(snprintf(message, 2, "%d", OP_CODE_DISCONNECT) < 0){
      fprintf(stderr, "[API] Failed to create disconnection request.\n");
      return 1;
    }

    // Writes the disconnection request to the server pipe
    if(write_all(req_fd, message, 1) == -1){
      fprintf(stderr, "[API] Failed to write the disconnection request to the request pipe.\n");
      if(errno == EPIPE){
        fprintf(stderr, "[API] Server connection lost.\n");
        close_and_unlink();
        return 2;
      }
      return 1;
    }

    // Reads the result of the disconnection from the response pipe
    int io_result;
    if((io_result = read_all(resp_fd, message, 2, NULL)) <= 0){
      fprintf(stderr, "[API] Failed to read the disconnection result from the response pipe.\n");
      if(io_result == 0)
        fprintf(stderr, "[API] Server connection lost.\n");
      close_and_unlink();
      return 2;
    }

    // Prints the result of the operation
    char response[48] = {'\0'};
    if(snprintf(response, 48,
       "Server returned %c for operation: disconnect.\n", message[1]) < 0){
      fprintf(stderr,"[API] Error in creating the message obtained form the server.\n");
      return 1;
    }
    write_all(1, response, 48);

    if(message[1] - '0' == 1) return 1;
  }
  
  // Closes pipes and unlinks pipes files
  close_and_unlink();
 
  return 0;
}

int kvs_subscribe(const char* key){
  // Creates the subscription request to be sent to the server
  char request[MAX_STRING_SIZE + 2] = {'\0'};
  if(snprintf(request, MAX_STRING_SIZE + 2, "%d%s", OP_CODE_SUBSCRIBE, key) < 0){
    fprintf(stderr, "[API] Failed to create subscription request.\n");
    return 1;
  }

  // Writes subscription request to the request pipe
  if(write_all(req_fd, request, MAX_STRING_SIZE + 2) == -1){
    fprintf(stderr, "[API] Failed to write the subscription request to the request pipe.\n");
    if(errno == EPIPE){
      close_and_unlink();
      fprintf(stderr, "[API] Server connection lost.\n");
      return 2;
    }
    return 1;
  }

  // Reads the result of the subscription from the response pipe
  int io_result;
  char result[2] = {'\0'};
  if((io_result = read_all(resp_fd, result, 2, NULL)) <= 0){
    fprintf(stderr, "[API] Failed to read the subscription result from the response pipe.\n");
    if(io_result == 0)
      fprintf(stderr, "[API] Server connection lost.\n");
    close_and_unlink();
    return 2;
  }
  
  // Prints the result of the operation
  char response[47] = {'\0'};
  if(snprintf(response, 47,
     "Server returned %c for operation: subscribe.\n", result[1]) < 0){
    fprintf(stderr,"[API] Error in creating the message obtained form the server.\n");
    return 1;
  }
  write_all(1, response, 47);

  return !(result[1] - '0');
}

int kvs_unsubscribe(const char* key){
  // Creates the unsubscription request to be sent to the server
  char request[MAX_STRING_SIZE + 2] = {'\0'};
  if(snprintf(request, MAX_STRING_SIZE + 2, "%d%s",
              OP_CODE_UNSUBSCRIBE, key) < 0){
    fprintf(stderr, "[API] Failed to create unsubscription request.\n");
    return 1;
  }

  // Writes unsubscription request to the request pipe
  if(write_all(req_fd, request, MAX_STRING_SIZE + 2) == -1){
    fprintf(stderr, "[API] Failed to write the unsubscription request to the request pipe.\n");
    if(errno == EPIPE){
      close_and_unlink();
      fprintf(stderr, "[API] Server connection lost.\n");
      return 2;
    }
    return 1;
  }

  // Reads the result of the unsubscription from the response pipe
  int io_result;
  char result[2] = {'\0'};
  if((io_result = read_all(resp_fd, result, 2, NULL)) <= 0){
    fprintf(stderr, "[API] Failed to read the unsubscription result from the validation pipe.\n");
    if(io_result == 0)
      fprintf(stderr, "[API] Server connection lost.\n");
    close_and_unlink();
    return 2;
  }

  // Prints the result of the operation
  char response[49] = {'\0'};
  if(snprintf(response, 49,
     "Server returned %c for operation: unsubscribe.\n", result[1]) < 0){
    fprintf(stderr,"[API] Error in creating the message obtained form the server.\n");
    return 1;
  }
  write_all(1, response, 49);

  return result[1] - '0';
}


